package testngallure;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

public class OpenMRSTests extends TestBase
{
	@Description("Validate the Contents of Manage Service Types Tabular Data")
	@Severity(SeverityLevel.CRITICAL)
	@Story("US_001 OpenMRS ->Manage Service Types -> Tabular Data")
	@Test (description = "Validate the Tabular Data")
	public void validateTabularDateofServiceTypes() throws Exception
	{
		OpenMRSPage mrsPage = new OpenMRSPage(driver);
		System.out.println("inside openmrstest");
		mrsPage.login();
		mrsPage.navigatetoAppoinmentPage();
		mrsPage.clickOnManageServiceTypes();
		 mrsPage.fetchTableRowContents();
		String expected ="Dermatology";
		//Assert.assertEquals(actual, expected);
	}
}